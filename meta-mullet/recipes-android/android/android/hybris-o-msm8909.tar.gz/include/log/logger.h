#ifndef _LIBS_LOG_LOGGER_H
#define _LIBS_LOG_LOGGER_H
#include <log/log.h>
#warning "Deprecated: do not include log/logger.h, use log/log.h instead"
#endif /*_LIBS_LOG_LOGGER_H*/
